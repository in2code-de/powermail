<?php
namespace In2code\Powermailextended\Domain\Repository;

/**
 * Class FormRepository
 * @package In2code\Powermailextended\Domain\Repository
 */
class FormRepository extends \In2code\Powermail\Domain\Repository\FormRepository {}