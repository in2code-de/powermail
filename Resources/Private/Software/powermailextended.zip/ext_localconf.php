<?php
// enable SignalSlot
//$signalSlotDispatcher = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\CMS\Extbase\SignalSlot\Dispatcher');
//$signalSlotDispatcher->connect(
//	'In2code\Powermail\Controller\FormController',
//	'createActionBeforeRenderView',
//	'In2code\Powermailextended\Controller\FormController',
//	'manipulateMailObjectOnCreate',
//	FALSE
//);